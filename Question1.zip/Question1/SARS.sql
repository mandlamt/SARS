
-- Supplier Table
CREATE TABLE SARSSuppliers (
  SupplierID int identity(1,1) ,
  SupplierName varchar(255) NOT NULL,
  Address varchar(255) NOT NULL,
  City varchar(255) NOT NULL,
  Region varchar(255) NOT NULL,
  PostalCode varchar(10) NOT NULL,
  Country varchar(255) NOT NULL,
  Phone varchar(20) NOT NULL,
  PRIMARY KEY (SupplierID)
);


-- Contact Table
CREATE TABLE Contacts (
  ContactID int identity(1,1) ,
  SupplierID int NOT NULL,
  ContactName varchar(255) NOT NULL,
  ContactTitle varchar(255) NOT NULL,
  PRIMARY KEY (ContactID),
  FOREIGN KEY (SupplierID) REFERENCES SARSSuppliers(SupplierID)
);

-- Admin Table
CREATE TABLE Admins (
    AdminID INT identity(1,1) ,
    AdminName VARCHAR(255),
    AdminRole VARCHAR(50),
    Username VARCHAR(50) UNIQUE,
    Password VARCHAR(255) -- Store encrypted passwords
	PRIMARY KEY (AdminID),
);



INSERT INTO SARSSuppliers (SupplierName, Address, City, Region, PostalCode, Country, Phone)
VALUES ('Acme Corporation', '123 Main Street', 'Anytown', 'CA', '12345', 'USA', '1-800-555-1212');


--drop TABLE SARSSuppliers 
--drop TABLE Contacts 
--drop TABLE Admins 