﻿namespace SupplierSARS.Controllers
{
    internal class SupplierListView
    {
        public object Suppliers { get; set; }
    }
}