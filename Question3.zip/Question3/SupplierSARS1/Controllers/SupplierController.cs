﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SupplierSARS.Controllers.SupplierSARS;
using SupplierSARS.Models;


namespace SupplierSARS.Controllers
{

    // Controller class for Supplier
    public class SupplierController : Controller
    {
        internal readonly ISupplierService _supplierService;

        public SupplierController(ISupplierService supplierService) => _supplierService = supplierService;

        public ActionResult Index()
        {
            var suppliers = _supplierService.GetAllSuppliers();
            if (suppliers == null)// || suppliers.Count == 0)
            {
                // Return a view with an empty model or a message
                return View();
                // or
              //  return View("NoData");
            }
            else
            {
                // Return a view with the data as model
                return View(new SupplierListView { Suppliers = suppliers });
            }
            
        }

        // A list of suppliers for demonstration purposes
        // You can replace this with a database connection
        private static List<Supplier> suppliers = new List<Supplier>()
    {
        new Supplier() { SupplierId = 1, SupplierName = "ABC Ltd.", Address = "123 Main Street",City = "Jhb",Region = "MIDRAND",PostalCode = "1685",Country = "SA",   Phone = "0123456789" },
        new Supplier() { SupplierId = 2, SupplierName = "XYZ Inc.", Address = "456 High Road",City = "PTA t",Region = "BKS", PostalCode = "2001",  Country = "SA", Phone = "0123456789" },
        new Supplier() { SupplierId = 3, SupplierName = "PQR Co.", Address = "789 Low Lane", City = "VAAL ",Region = "BTL", PostalCode = "1980", Country = "SA", Phone = "0123456789"}
    };

        public ActionResult Add()
        {
            return View(new SupplierAddView { Supplier = new Supplier() });
        }

        [HttpPost]
        public ActionResult Add(SupplierAddView model)
        {
            if (ModelState.IsValid)
            {
                _supplierService.AddSupplier(model.Supplier);
                return RedirectToAction("Index");
            }

            return View(model);
        }

        public ActionResult Update(int id)
        {
            var supplier = _supplierService.GetSupplierById(id);
            return View(new SupplierUpdateView { Supplier = supplier });
        }

        [HttpPost]
        public ActionResult Update(SupplierUpdateView model)
        {
            if (ModelState.IsValid)
            {
                _supplierService.UpdateSupplier(model.Supplier);
                return RedirectToAction("Index");
            }

            return View(model);
        }

        public ActionResult Delete(int id)
        {
            var supplier = _supplierService.GetSupplierById(id);
            return View(new SupplierDeleteView { Supplier = supplier });
        }
    }




    namespace SupplierSARS
    {
       public class ISupplierService
        {
            public void AddSupplier(object supplier)
            {
                throw new NotImplementedException();
            }

            public object GetAllSuppliers()
            {
                throw new NotImplementedException();
            }

            public object GetSupplierById(int id)
            {
                throw new NotImplementedException();
            }

            public void UpdateSupplier(object supplier)
            {
                throw new NotImplementedException();
            }
        }
    }
    namespace SupplierSARS
    {
        class SupplierDeleteView
        {
            public object Supplier { get; set; }
        }
    }
}