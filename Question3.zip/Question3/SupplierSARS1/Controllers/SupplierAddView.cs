﻿using SupplierSARS.Models;

namespace SupplierSARS.Controllers
{
    public class SupplierAddView
    {
        public Supplier Supplier { get; set; }
    }
}