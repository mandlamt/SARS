﻿namespace SupplierSARS.Controllers
{
    public class SupplierUpdateView
    {
        public object Supplier { get; set; }
    }
}