﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace SARSSupplier
{

    public class Supplier
    {

        public int SupplierId { get; set; }  
        public string SupplierName { get; set; }
          
        public string Address { get; set; }
        public string City { get; set; }
        public string Region { get; set; }
        public string PostalCode { get; set; }
        public string Country { get; set; }
        public string Phone { get; set; }
        // Navigation property
        public virtual ICollection<Contacts> Contacts { get; set; }
    }






    public class Contacts
    {
      
        public int ContactId { get; set; }



        public string ContactName { get; set; }


        public string ContactTitle { get; set; }
      

        // Foreign key
      //  [ForeignKey("Supplier")]
        public int SupplierId { get; set; }

        // Navigation property
        public virtual Supplier Supplier { get; set; }
    }
}
