﻿using Microsoft.EntityFrameworkCore;
namespace SARSSupplier // Replace with your actual namespace
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Contacts> Contacts { get; set; }
        public ApplicationDbContext(DbContextOptions<DbContext> options) : base(options)
        {
        }
    }

    public class DbSet<T>
    {
    }

    public class DbContext
    {
        public DbContext(DbContextOptions<DbContext> options)
        {
        }
    }

    public class DbContextOptions<T>
    {
    }
}